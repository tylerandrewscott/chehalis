

qpdf _contracts/*.pdf --pages . 1 -- _firstpage/*.pdf
qpdf input.pdf --pages . 1-30 -- output.pdf